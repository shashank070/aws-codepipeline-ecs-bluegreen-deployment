/*window._config = {
    cognito: {
        userPoolId: 'us-east-1_t3yAhSAww', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
		clientId: '6195q9r5ebb0r1euhl4qtg5ntq' //is this used anywhere?
    },
};
*/
window._config = {
	    cognito: {
	        userPoolId: 'ap-southeast-1_DSl1pQ34S', // e.g. us-east-2_uXboG5pAb
	        region: 'ap-southeast-1', // e.g. us-east-2
			clientId: '4tgntq8564f7qobd3fe9llqhnn' //is this used anywhere?
	    },
	};

